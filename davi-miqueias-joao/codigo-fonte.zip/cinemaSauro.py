import psycopg2
import os
import datetime

class bcolors:  
    OK = '\033[92m' #GREEN
    WARNING = '\033[93m' #YELLOW
    FAIL = '\033[91m' #RED
    RESET = '\033[0m' #RESET COLOR

hostname = "localhost"
database = "cinema-sauro"
username = "postgres"
password = "superclass"
port_id = 5433
sslmode="require"

conn_string = "host={0} user={1} dbname={2} password={3} port={4}".format(hostname, username, database, password, port_id)

conn = psycopg2.connect(conn_string)

cursor = conn.cursor()

# DATAS UTILIZADAS COMO HOJE (2022-11-22, 2023-01-01, 2022-11-29)
# FUNCIONALIDADES 
def salvar():
  conn.commit()

def criar_usuario(nome, categoria, senha):
  cursor.execute("INSERT INTO cliente(nome, categoria, senha) VALUES(%s, %s, %s)", (nome, categoria, senha))
  cursor.execute("SELECT * FROM Cliente C WHERE C.senha = %s", [senha])
  salvar()
  return cursor.fetchall()[0][0]

def encontrar_por_senha(senha):
  cursor.execute("SELECT C.categoria, C.nome, C.id_cliente FROM Cliente C WHERE C.senha=%s", [senha])
  usuario = cursor.fetchall()
  return usuario

def listar_filmes_hoje():
  data_atual = "2022-11-22"
  cursor.execute("SELECT F.id_filme, F.nome FROM Filme F WHERE F.data_estreia=%s", [data_atual])
  return cursor.fetchall()

def listar_filmes_em_breve():
  data_atual = "2022-11-22"
  cursor.execute("SELECT F.id_filme, F.nome, F.data_estreia FROM Filme F WHERE F.data_estreia<>%s", [data_atual])
  return cursor.fetchall()

def listar_sessoes_filme(id_filme):
  cursor.execute("SELECT F.nome, S.id_sessao, S.horario_exibicao, S.num_sala, SS.capacidade FROM Filme F, Sessao S, Sala SS WHERE F.id_filme=%s AND S.id_filme = F.id_filme AND SS.num_sala = S.num_sala", [id_filme])
  return cursor.fetchall()

def listar_itens_lanchonete():
  cursor.execute("SELECT * FROM Itens_lanchonete")
  return cursor.fetchall()
  
def listar_itens_lanchonete_promocionais(dia):
  cursor.execute("SELECT IL.id_item, IL.nome_item, IL.preco_item FROM Itens_lanchonete IL WHERE IL.data_oferta=%s", [dia])
  return cursor.fetchall()

def quantidade_disponivel_sessao(id_sessao):
  cursor.execute("SELECT S.quantidade_sessao FROM Sessao S WHERE S.id_sessao = %s", [id_sessao])
  return cursor.fetchall()

def obter_preco_categoria(categoria_usuario, preco):
  PRECO_CATEGORIA = {
    "Infantil": 0.25,
    "Adulto": 1,
    "Flamenguista" : 0,
    "Idoso": 0.5,
    "Estudante": 0.5
  } 

  return float(preco) * PRECO_CATEGORIA[categoria_usuario]

def obter_preco(categoria_usuario, dia_da_semana):
  cursor.execute("SELECT PS.preco FROM Preco_semana PS WHERE PS.dia_da_semana = %s", [dia_da_semana])
  preco = cursor.fetchall()[0][0]
  preco = obter_preco_categoria(categoria_usuario, preco)

  return preco

def obter_preco_ingressos(id_sessao, quantidade, categoria_usuario):
  quantidade_disponivel = quantidade_disponivel_sessao(id_sessao)

  if quantidade_disponivel[0][0] < int(quantidade):
    print("Quantidade indisponível!")
    return -1

  DIAS = ['Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado', 'Domingo']

  dia_da_semana = DIAS[datetime.date(2023, 12, 17).weekday()]
  preco_total = obter_preco(categoria_usuario, dia_da_semana) * quantidade

  return preco_total

def detalhar_filme(id_filme):
  cursor.execute("SELECT F.nome, F.tempo_exibicao, F.data_estreia, F.classificacao_indicativa, F.nome_empresa FROM Filme F WHERE F.id_filme = %s", [id_filme])
  return cursor.fetchall()

def listar_formas_de_pagamento():
  cursor.execute("SELECT * FROM Pagamento")
  return cursor.fetchall()

def obter_categoria_usuario(id_cliente):
  cursor.execute("SELECT C.categoria FROM Cliente C WHERE C.id_cliente = %s", [id_cliente])
  return cursor.fetchall()

def reduzir_quantidade_sessao(id_sessao, quantidade):
  nova_quantidade = quantidade_disponivel_sessao(id_sessao)[0][0] - quantidade
  cursor.execute("UPDATE Sessao SET quantidade_sessao = %s WHERE Sessao.id_sessao = %s", [nova_quantidade, id_sessao])
  salvar()

def gerar_ingresso(id_compra, id_sessao, id_cliente):
  categoria_cliente = obter_categoria_usuario(id_cliente)[0][0]

  cursor.execute("INSERT INTO ingresso(categoria, id_sessao, id_compra) VALUES(%s, %s, %s)", [categoria_cliente, id_sessao, id_compra])

  salvar()

def inicializar_compra(id_cliente, forma_de_pag, valor_ingresso):
  data_atual = "2022-11-22"
  valor_ingresso = 0

  if forma_de_pag == 1:
    valor_ingresso = valor_ingresso * 1.1

  cursor.execute("INSERT INTO compra(id_cliente, id_pag, data_compra, valor_total) VALUES(%s, %s, %s, %s) RETURNING id_compra", [id_cliente, forma_de_pag, data_atual, valor_ingresso])

  salvar()

  return cursor.fetchall()[0][0]

def imprimir_voucher(id_voucher):
  cursor.execute("SELECT V.id_voucher, I.nome_item, I.preco_item, VI.quantidade FROM Voucher_lanchonete V JOIN Voucher_itens_lanchonete VI ON V.id_voucher = VI.id_voucher JOIN Itens_lanchonete I ON VI.id_item = I.id_item WHERE V.id_voucher = %s", [id_voucher])

  informacoes_voucher = cursor.fetchall()

  print(bcolors.OK + "\n=============================== INFORMAÇÕES DO SEU VOUCHER LANCHONETE: ===============================\n" + bcolors.RESET)
  print("O número do voucher gerado é: ", informacoes_voucher[0][0])

  valor_total_voucher = 0

  for item in informacoes_voucher:
    valor_total_voucher += (item[2] * item[3]) 
    print("O nome do item da lachonete comprado é: ", item[1])
    print("O preco do item da lachonete comprado é: ", item[2])
    print("A quantidade comprada do item acima foi: ", item[3])
  
  print("O valor total do seu voucher é: ", valor_total_voucher)

  atualizarValorDeCompra(float(valor_total_voucher), comprando)

def gerar_voucher(lista_itens_selecionados, quantidade_itens):
  cursor.execute("INSERT INTO voucher_lanchonete(qtd_itens) VALUES(%s) RETURNING id_voucher", [quantidade_itens])
  id_voucher_criado = cursor.fetchall()[0][0]
  for item in lista_itens_selecionados:
    id_item = item[0]
    quantidade = item[1]
    cursor.execute("INSERT INTO voucher_itens_lanchonete(id_voucher, id_item, quantidade) VALUES(%s, %s, %s)", [id_voucher_criado, id_item, quantidade])
  salvar()
  imprimir_voucher(id_voucher_criado)
  return id_voucher_criado

def escolha_de_itens():
  data_escolhida = "2022-12-17"
  deseja_comprar = int(input("Deseja obter algum item da lanchonete? Digite 1 para sim e 0 para não: "))
  if (deseja_comprar == 0): return
  quantidade_itens = 0
  opcao_escolhida = 0
  lista_itens_selecionados = []

  while (opcao_escolhida != -1):
    print("Veja a lista abaixo:\n")
    print("Itens promocionais: ")
    for item in listar_itens_lanchonete_promocionais(data_escolhida):
      print(bcolors.WARNING + f"{item[0]} - {item[1]}" + bcolors.RESET)

    opcao_escolhida = int(input("Digite o numero do item que deseja, 0 para listar todos, ou -1 para sair: "))
    if (opcao_escolhida == 0):
      for item in listar_itens_lanchonete():
          print(bcolors.WARNING + f"{item[0]} - {item[1]}" + bcolors.RESET)

      continue

    if (opcao_escolhida > 0):
      item_estava_selecionado = 0
      for item in lista_itens_selecionados:
        if (item[0] == opcao_escolhida):
          item_estava_selecionado = 1
          item[1] = item[1] + 1
    
      if (item_estava_selecionado == 0):
        lista_itens_selecionados.append([opcao_escolhida, 1])

      quantidade_itens += 1
      algo_mais = int(input("Deseja comprar mais algum item: [0 - Não, 1 -Sim]"))
      if (algo_mais): continue

      opcao_escolhida = -1

      id_voucher_gerado = gerar_voucher(lista_itens_selecionados, quantidade_itens)
      return id_voucher_gerado
      
def atualizarValorDeCompra(valor_para_adicionar, comprando):
  cursor.execute("SELECT valor_total, id_pag FROM compra WHERE compra.id_compra = %s", [comprando])
  retorno = cursor.fetchall()

  forma_de_pagamento = retorno[0][1]


  if forma_de_pagamento == 1:
    valor_para_adicionar *= 1.1
  
  valorTotal = float(retorno[0][0]) + valor_para_adicionar
  cursor.execute("UPDATE compra SET valor_total = %s WHERE compra.id_compra = %s", [valorTotal, comprando])
  salvar()

def adicionar_voucher_a_compra(id_voucher_cliente, comprando):
  cursor.execute("UPDATE Compra SET id_voucher = %s WHERE Compra.id_compra = %s", [id_voucher_cliente, comprando])

def exibirCompra(comprando):
  cursor.execute("SELECT C.id_pag, C.data_compra, C.id_voucher, C.valor_total, P.forma_pag FROM Compra C JOIN Pagamento P ON P.id_pag = C.id_pag WHERE C.id_compra = %s", [comprando])
  informacoes_da_compra = cursor.fetchall()

  valor_total = float(informacoes_da_compra[0][3])

  print(bcolors.OK + "\n=============================== INFORMAÇÕES DA SUA COMPRA GERAL: ===============================\n" + bcolors.RESET)
  print("A forma de pagamento escolhida foi: ", informacoes_da_compra[0][4])
  print("A data da compra realizada foi: ", informacoes_da_compra[0][1])
  print("Número de voucher gerado: ", informacoes_da_compra[0][2])
  print("O valor total da sua compra foi de : ", valor_total)

# CRIANDO USUÁRIO E LOGANDO
print(bcolors.OK + "\n=============================== BEM VINDO AO CINEMASSAURO: ===============================\n" + bcolors.RESET)
id_cliente_atual = 0

possui_cadastro = int(input("Você possui cadastro? 0 - Não, 1 - Sim: "))

categoria_usuario = ""

if possui_cadastro == 1:
  while(1):
    senha_usuario = int(input(bcolors.OK + "Digite sua senha: " + bcolors.RESET))
    resultado = encontrar_por_senha(senha_usuario)
    categoria_usuario = resultado[0][0]

    if resultado:
      id_cliente_atual = resultado[0][2]

    if len(resultado) == 1:
      os.system('cls||clear')
      print(bcolors.OK + "********************USUÁRIO LOGADO NO SISTEMA******************** \n" + bcolors.RESET)
      print(f"Id: {resultado[0][2]} - Nome: {resultado[0][1]} - Categoria: {resultado[0][0]}")
      break
elif possui_cadastro != 0 or possui_cadastro != 1:
  print(bcolors.FAIL + "\nUsuário não cadastrado! Por favor, faça seu cadastro na plataforma." + bcolors.RESET)
  print(bcolors.OK + "\n=============================== CADASTRO DE USUÁRIO ===============================\n" + bcolors.RESET)
  print(bcolors.OK + "\nEscolha uma das categorias: Infantil - Adulto - Flamenguista(entrada de graça) - Idoso - Estudante \n" + bcolors.RESET)
  print(bcolors.WARNING + "Digite seu nome, sua categoria e senha para realizar o cadastro, por favor!\n" + bcolors.RESET)
  nome_usuario = input("Digite seu nome: ")
  categoria_usuario = input("Digite sua categoria: ")
  senha_usuario = int(input("Digite sua senha: "))

  id_cliente_atual = criar_usuario(nome_usuario, categoria_usuario, senha_usuario)

comprando = -1
id_voucher_cliente = 0

while(1):
  print(bcolors.OK + "\n=============================== MENU DE OPÇÕES ===============================\n" + bcolors.RESET)
  print("0 - sair da aplicação")
  print("1 - listar filmes")
  print("2 - comprar ingressos")
  opcao_principal = int(input("\nDigite sua opção: "))

  if opcao_principal == 1:
    os.system('cls||clear')
    print(bcolors.OK + "\n=============================== LISTAR FILMES ===============================\n" + bcolors.RESET)


    while(1):
      escolha = int(input("\nDigite: 0 - para voltar \nDigite: 1 - para ver os filmes de hoje\nDigite: 2 - para ver os filmes que vão estrear em breve\nDigite: 3 - para ver os detalhes do filme desejado \n"))
      if escolha == 0:
        os.system('cls||clear')
        break
      elif escolha == 1:
        os.system('cls||clear')
        print(bcolors.OK + "\n=============================== FILMES DE HOJE ===============================\n" + bcolors.RESET)
        for filme in listar_filmes_hoje():
          print(bcolors.WARNING + f"{filme[0]} - {filme[1]}" + bcolors.RESET)
          
        continue
      elif escolha == 3: 
        id_filme = int(input("Digite o número do filme desejado para ver mais detalhes ou digite 0 para voltar: "))
        if id_filme == 0:
          continue
        result = detalhar_filme(id_filme)
        print(bcolors.FAIL + f"\nFilme: {result[0][0]} - Duração: {result[0][1]} minutos - data de estreia: {result[0][2]} - Classificação indicativa: {result[0][3]} - Empresa produtora: {result[0][4]}" + bcolors.RESET)
        continue
      else:
        os.system('cls||clear')
        print(bcolors.OK + "\n=============================== FILMES QUE VÃO ESTREAR ===============================\n" + bcolors.RESET)
        for filme in listar_filmes_em_breve():
          print(bcolors.WARNING + f"{filme[0]} - {filme[1]} - {filme[2]}" + bcolors.RESET)
        continue
  elif opcao_principal == 2:
    while(1):
      os.system('cls||clear')
      print(bcolors.OK + "\n=============================== COMPRAR INGRESSOS ===============================\n" + bcolors.RESET)
      print("Digite 0 - para voltar")
      print("Digite 1 - para ver os ingressos referentes aos filmes de hoje")
      print("Digite 2 - para ver os ingressos dos filmes que vão estrear em breve")
      escolha = int(input("\nDigite a sua opção: "))
      if escolha == 0:
        os.system('cls||clear')
        if comprando != -1:
          id_voucher_cliente = escolha_de_itens()
          adicionar_voucher_a_compra(id_voucher_cliente, comprando)
          exibirCompra(comprando)
        break
      else:
        while(1):
          if escolha == 1:
            os.system('cls||clear')   
            print(bcolors.OK + "\n=============================== FILMES DE HOJE ===============================\n" + bcolors.RESET)
            for filme in listar_filmes_hoje():
              print(bcolors.WARNING + f"{filme[0]} - {filme[1]}" + bcolors.RESET)
          elif escolha == 2: 
            # os.system('cls||clear')
            print(bcolors.OK + "\n=============================== FILMES EM BREVE ===============================\n" + bcolors.RESET)
            for filme in listar_filmes_em_breve():
              print(bcolors.WARNING + f"{filme[0]} - {filme[1]} - {filme[2]}" + bcolors.RESET)

          opcao_filme = int(input("Digite o número do filme que você deseja ou digite 0 para voltar: "))

          if opcao_filme == 0:
            break
            
          if len(listar_sessoes_filme(opcao_filme)) == 0:
            print("FILME SEM SESSÃO!")
            continue  

          for sessao in listar_sessoes_filme(opcao_filme):
            print(bcolors.OK + "\n=============================== INFORMAÇÕES DA SESSÃO DO FILME ===============================\n" + bcolors.RESET)
            print(bcolors.FAIL + f"Sessão {sessao[1]} - Filme {sessao[0]} - {sessao[2]} - Sala {sessao[3]} - capacidade {sessao[4]}\n" + bcolors.RESET)

          print(bcolors.OK + "\n=============================== COMPRAR INGRESSOS ===============================\n" + bcolors.RESET)

          opcao_sessao = input("\nDigite a sessao que deseja: ")
          quantidade_ingresso = int(input("Digite a quantidade de ingressos que você quer comprar: "))
          valor_total_ingresso = obter_preco_ingressos(opcao_sessao, quantidade_ingresso, categoria_usuario)
          if valor_total_ingresso == -1:
            continue

          print(bcolors.FAIL + "\nValor total dos ingressos comprados: " + bcolors.RESET, valor_total_ingresso)    
          
          if (comprando == -1):
            formas_de_pag = listar_formas_de_pagamento()
            print(bcolors.OK + "\nAgora escolha a forma de pagamento: " + bcolors.RESET)
            for forma in formas_de_pag:
              print(f"{forma[0]} - {forma[1]}")
            pagamento_escolhido = int(input("\nDigite o número correspondente a sua forma de pagamento: "))
            comprando = inicializar_compra(id_cliente_atual, pagamento_escolhido, valor_total_ingresso)
            gerar_ingresso(comprando, opcao_sessao, id_cliente_atual)
            reduzir_quantidade_sessao(opcao_sessao, quantidade_ingresso)
          else:
            gerar_ingresso(comprando, opcao_sessao, id_cliente_atual)
            if (comprando != -1): atualizarValorDeCompra(valor_total_ingresso, comprando)
            reduzir_quantidade_sessao(opcao_sessao, quantidade_ingresso)
  else:
    break

cursor.close()
conn.close()