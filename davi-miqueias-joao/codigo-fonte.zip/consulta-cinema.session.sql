DROP TABLE IF EXISTS cliente CASCADE;
DROP TABLE IF EXISTS compra CASCADE;
DROP TABLE IF EXISTS pagamento CASCADE;
DROP TABLE IF EXISTS ingresso CASCADE;
DROP TABLE IF EXISTS voucher_lanchonete CASCADE;
DROP TABLE IF EXISTS preco_semana CASCADE;
DROP TABLE IF EXISTS itens_lanchonete CASCADE;
DROP TABLE IF EXISTS sessao CASCADE;
DROP TABLE IF EXISTS sala CASCADE;
DROP TABLE IF EXISTS filme CASCADE;
DROP TABLE IF EXISTS ator CASCADE;
DROP TABLE IF EXISTS categoria_filme CASCADE;
DROP TABLE IF EXISTS empresa_produtora CASCADE;
DROP TABLE IF EXISTS filme_ator CASCADE;
DROP TABLE IF EXISTS filme_categoria CASCADE;
DROP TABLE IF EXISTS voucher_itens_lanchonete;

--CRIANDO TABELAS
CREATE TABLE cliente(
  id_cliente SERIAL NOT NULL PRIMARY KEY,
  nome VARCHAR(60) NOT NULL,
  categoria VARCHAR(60) NOT NULL,
  senha INT NOT NULL
);

CREATE TABLE pagamento(
  id_pag SERIAL NOT NULL PRIMARY KEY, 
  forma_pag VARCHAR(60) NOT NULL
);

CREATE TABLE voucher_lanchonete(
  id_voucher SERIAL NOT NULL PRIMARY KEY,
  qtd_itens INT NOT NULL
);

CREATE TABLE preco_semana(
  id_preco_ingresso SERIAL NOT NULL PRIMARY KEY,
  preco DECIMAL NOT NULL,
  dia_da_semana VARCHAR(60) NOT NULL
);

CREATE TABLE itens_lanchonete(
  id_item SERIAL NOT NULL PRIMARY KEY,
  nome_item VARCHAR(60) NOT NULL,
  preco_item DECIMAL NOT NULL,
  data_ofeta DATE
);

CREATE TABLE compra(
  id_compra SERIAL NOT NULL PRIMARY KEY,
  id_cliente INT NOT NULL,
  id_pag INT NOT NULL,
  data_compra DATE NOT NULL,
  id_voucher INT NOT NULL,
  valor_total DECIMAL,

  CONSTRAINT efetua FOREIGN KEY (id_cliente) REFERENCES cliente(id_cliente),
  CONSTRAINT paga FOREIGN KEY(id_pag) REFERENCES pagamento(id_pag),
  CONSTRAINT possui FOREIGN KEY(id_voucher) REFERENCES voucher_lanchonete(id_voucher)
);

CREATE TABLE sala(
  num_sala SERIAL NOT NULL PRIMARY KEY,
  capacidade INTEGER NOT NULL
);

CREATE TABLE ator(
  id_ator SERIAL NOT NULL PRIMARY KEY,
  nome_ator VARCHAR(60) NOT NULL,
  nacionalidade VARCHAR(60) NOT NULL,
  sexo VARCHAR(60) NOT NULL,
  idade INTEGER NOT NULL
);

CREATE TABLE categoria_filme(
  id_categoria SERIAL NOT NULL PRIMARY KEY,
  nome_categoria VARCHAR(60) NOT NULL
);

CREATE TABLE empresa_produtora(
  nome_empresa VARCHAR(60) NOT NULL PRIMARY KEY,
  tipo_empresa VARCHAR(60) NOT NULL
);

CREATE TABLE filme(
  id_filme SERIAL NOT NULL PRIMARY KEY,
  nome VARCHAR(60) NOT NULL,
  tempo_exibicao INTEGER NOT NULL,
  data_estreia DATE DEFAULT NULL,
  classificacao_indicativa INTEGER NOT NULL, 
  nome_empresa VARCHAR(60) NOT NULL,

  CONSTRAINT nome_da_empresa FOREIGN KEY(nome_empresa) REFERENCES empresa_produtora(nome_empresa)
);

CREATE TABLE sessao(
  id_sessao SERIAL NOT NULL PRIMARY KEY,
  data_exibicao DATE NOT NULL,
  horario_exibicao TIME NOT NULL,
  num_sala INT NOT NULL,
  id_filme INT NOT NULL,
  quantidade_sessao INT NOT NULL

  CONSTRAINT aloca FOREIGN KEY(num_sala) REFERENCES sala(num_sala),
  CONSTRAINT exibe FOREIGN KEY(id_filme) REFERENCES filme(id_filme)
);

CREATE TABLE ingresso(
  id_ingresso SERIAL NOT NULL PRIMARY KEY,
  categoria VARCHAR(60) NOT NULL,
  id_sessao INT NOT NULL,
  id_compra INT NOT NULL,

  CONSTRAINT comprado FOREIGN KEY(id_compra) REFERENCES compra(id_compra),
  CONSTRAINT acesso FOREIGN KEY(id_sessao) REFERENCES sessao(id_sessao)
);

--ADICIONANDO RELACIONAMENTOS
CREATE TABLE filme_ator(
  id SERIAL NOT NULL PRIMARY KEY,
  id_filme INT NOT NULL,
  id_ator INT NOT NULL,

  CONSTRAINT participa FOREIGN KEY (id_filme) REFERENCES filme(id_filme),
  CONSTRAINT atua FOREIGN KEY (id_ator) REFERENCES ator(id_ator)
);

CREATE TABLE filme_categoria(
  id SERIAL NOT NULL PRIMARY KEY,
  id_filme INT NOT NULL,
  id_categoria INT NOT NULL,

  CONSTRAINT associado FOREIGN KEY (id_filme) REFERENCES filme(id_filme),
  CONSTRAINT tem FOREIGN KEY (id_categoria) REFERENCES categoria_filme(id_categoria)
);

CREATE TABLE voucher_itens_lanchonete(
  id SERIAL NOT NULL PRIMARY KEY,
  id_voucher INT NOT NULL,
  id_item INT NOT NULL,
  quantidade INT,


  CONSTRAINT voucher_item FOREIGN KEY(id_voucher) REFERENCES voucher_lanchonete(id_voucher),
  CONSTRAINT identi_item FOREIGN KEY(id_item) REFERENCES itens_lanchonete(id_item)
);