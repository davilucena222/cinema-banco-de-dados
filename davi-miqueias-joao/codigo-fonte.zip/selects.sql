
SELECT * FROM compra;

-- DELETE FROM ingresso WHERE categoria = 'Jovem';
-- DELETE FROM cliente WHERE categoria = 'Jovem';

-- UPDATE Cliente SET categoria = 'Idoso' WHERE Cliente.nome = 'Davi'; 

-- UPDATE Filme SET data_estreia = '2023-12-17' WHERE Filme.id_filme = 41; 
-- UPDATE Compra SET id_voucher = 10 WHERE Compra.id_compra = 20; 
-- SELECT * FROM voucher_lanchonete;

-- SELECT DISTINCT S.num_sala, F.id_filme, SS.horario_exibicao, SS.data_exibicao FROM Sala S, Filme F, Sessao SS WHERE F.id_filme = 16 AND SS.id_filme = F.id_filme AND SS.num_sala = S.num_sala;

-- SELECT F.id_filme FROM Filme F, Sessao SS WHERE SS.id_filme NOT NULL AND SS.id_filme = F.id_filme;

-- SELECT F.id_filme, F.nome, F.classificacao_indicativa FROM Filme F WHERE F.data_estreia = '2022-11-22';

-- SELECT F.nome, A.nacionalidade, A.nome_ator FROM Filme F JOIN Filme_ator FF ON F.id_filme = FF.id_filme JOIN Ator A ON FF.id_ator = A.id_ator WHERE F.id_filme = 24;

-- SELECT DISTINCT CF.nome_categoria, F.nome FROM Filme_categoria FF JOIN Filme F ON F.id_filme = FF.id_filme JOIN Categoria_filme CF ON CF.id_categoria = FF.id_categoria WHERE F.id_filme = 22;

-- SELECT DISTINCT C.nome, C.categoria, CC.valor_total, C.id_cliente, SS.num_sala, SS.data_exibicao, SS.horario_exibicao FROM Cliente C, Compra CC, Ingresso I, Sessao SS WHERE C.id_cliente = 3 AND CC.id_cliente = C.id_cliente AND I.id_compra = CC.id_compra AND I.id_sessao = SS.id_secao;

-- SELECT DISTINCT CF.nome_categoria, F.nome FROM Filme_categoria FF JOIN Filme F ON F.id_filme = FF.id_filme JOIN Categoria_filme CF ON CF.id_categoria = FF.id_categoria WHERE F.id_filme = 22;

-- SELECT DISTINCT A.nome_ator, F.classificacao_indicativa, CF.nome_categoria, F.tempo_exibicao, EP.nome_empresa FROM Filme F JOIN Filme_ator FA ON F.id_filme = FA.id_filme JOIN Ator A ON FA.id_ator = A.id_ator JOIN Filme_categoria FC ON F.id_filme = FC.id_filme JOIN Empresa_produtora EP ON EP.nome_empresa = EP.nome_empresa JOIN Categoria_filme CF ON CF.id_categoria = FC.id_categoria WHERE F.id_filme = 17;

-- SELECT S.id_sessao, S.data_exibicao, S.num_sala, F.nome FROM Filme F, Sessao S WHERE F.nome='Pedro na copa' AND S.id_filme = F.id_filme;

-- SELECT IL.id_item, IL.nome_item, IL.preco_item FROM Itens_lanchonete IL WHERE IL.data_oferta='2022-11-22';

-- SELECT S.id_sessao, S.data_exibicao, S.num_sala, F.nome FROM Filme F, Sessao S WHERE F.id_filme=31 AND S.id_filme = F.id_filme

-- SELECT * FROM sessao;

-- DELETE FROM ingresso CASCADE;
-- DELETE FROM compra CASCADE;
-- DELETE FROM cliente CASCADE;
-- SELECT * FROM compra;
-- SELECT * FROM compra;
-- SELECT * FROM cliente;
-- SELECT * FROM itens_lanchonete;
-- SELECT * FROM sessao;
-- SELECT * FROM voucher_itens_lanchonete;
-- DELETE FROM voucher_itens_lanchonete;
-- DELETE FROM itens_lanchonete CASCADE;

-- ALTER TABLE compra ALTER COLUMN id_voucher DROP NOT NULL;
-- SELECT * FROM compra;

-- SELECT * FROM ingresso;
-- ALTER TABLE sessao ADD quantidade_sessao INT;

-- UPDATE Sessao SET quantidade_sessao = Sala.capacidade FROM Sala WHERE Sessao.num_sala = Sala.num_sala; 

-- SELECT * FROM sessao;

-- ALTER TABLE voucher_itens_lanchonete ADD quantidade INT;

-- SELECT * FROM voucher_itens_lanchonete;

-- SELECT V.id_voucher, I.nome_item, I.preco_item, VI.quantidade FROM Voucher_lanchonete V JOIN Voucher_itens_lanchonete VI ON V.id_voucher = VI.id_voucher JOIN itens_lanchonete I ON VI.id_item = I.id_item WHERE V.id_voucher = 15;