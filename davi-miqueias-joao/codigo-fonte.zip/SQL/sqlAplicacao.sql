-- TODOS OS SELECTS DA APLICAÇÃO
SELECT * FROM Cliente C WHERE C.senha = %s, [senha];
SELECT * FROM Cliente C WHERE C.senha=%s, [senha];
SELECT F.id_filme, F.nome FROM Filme F WHERE F.data_estreia=%s, [data_atual];
SELECT F.nome, F.data_estreia FROM Filme F WHERE F.data_estreia<>%s, [data_atual];
SELECT F.nome, S.id_sessao, S.horario_exibicao, S.num_sala, SS.capacidade FROM Filme F, Sessao S, Sala SS WHERE F.id_filme=%s AND S.id_filme = F.id_filme AND SS.num_sala = S.num_sala, [id_filme];
SELECT * FROM Itens_lanchonete;
SELECT IL.id_item, IL.nome_item, IL.preco_item FROM Itens_lanchonete IL WHERE IL.data_oferta=%s, [dia];
SELECT S.quantidade_sessao FROM Sessao S WHERE S.id_sessao = %s, [id_sessao];
SELECT PS.preco FROM Preco_semana PS WHERE PS.dia_da_semana = %s, [dia_da_semana];
SELECT F.nome, F.tempo_exibicao, F.data_estreia, F.classificacao_indicativa, F.nome_empresa FROM Filme F WHERE F.id_filme = %s;
SELECT * FROM Pagamento;
SELECT C.categoria FROM Cliente C WHERE C.id_cliente = %s, [id_cliente];
SELECT valor_total FROM compra WHERE compra.id_compra = %s, [comprando];
SELECT V.id_voucher, I.nome_item, I.preco_item, VI.quantidade FROM Voucher_lanchonete V JOIN Voucher_itens_lanchonete VI ON V.id_voucher = VI.id_voucher JOIN itens_lanchonete I ON VI.id_item = I.id_item WHERE V.id_voucher = 15;

-- TODOS OS UPDATES DA APLICAÇÃO
UPDATE Sessao SET quantidade_sessao = %s WHERE Sessao.id_sessao = %s,[nova_quantidade, id_sessao];
UPDATE compra SET valor_total = %s WHERE compra.id_compra = %s, [valorTotal, comprando];

-- TODOS OS INSERTS DA APLICAÇÃO 
INSERT INTO ingresso(categoria, id_sessao, id_compra) VALUES(%s, %s, %s), [categoria_cliente, id_sessao, id_compra];
INSERT INTO compra(id_cliente, id_pag, data_compra, valor_total) VALUES(%s, %s, %s, %s) RETURNING id_compra, [id_cliente, forma_de_pag, data_atual, valor_ingresso];
INSERT INTO voucher_lanchonete(qtd_itens) VALUES(%s) RETURNING id_voucher, [quantidade_itens];
INSERT INTO voucher_itens_lanchonete(id_voucher, id_item, quantidade) VALUES(%s, %s, %s), [id_voucher_criado, id_item, quantidade];
INSERT INTO cliente(nome, categoria, senha) VALUES(%s, %s, %s), (nome, categoria, senha);